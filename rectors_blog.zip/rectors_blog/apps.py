from django.apps import AppConfig


class ExecutiveBlogConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rectors_blog'
    verbose_name = 'Блог Руководителя'